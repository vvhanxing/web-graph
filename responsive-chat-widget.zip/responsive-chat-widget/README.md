# Responsive Chat Widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/ramilulu/pen/mrNoXw](https://codepen.io/ramilulu/pen/mrNoXw).

Chat widget