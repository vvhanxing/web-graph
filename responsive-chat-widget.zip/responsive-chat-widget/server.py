from flask import Flask,render_template
from flask import jsonify
from flask import request

import json 



app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():

    return render_template('index.html')




if __name__ == '__main__':
    app.run(host='localhost',debug=True,port=5000)
   
#debug=False,host='192.168.1.111',port=5000 192.168.9.106
    #ipconfig 192.168.1.111
