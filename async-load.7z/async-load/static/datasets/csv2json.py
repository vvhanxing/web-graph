import pandas as pd
import json
from collections import OrderedDict
import math
import os
import sys
import random
def csv2graph(csv_name):   
    
    df = pd.read_csv(csv_name)

    bb1_index = 16
    bb2_index = 17
    bb3_index = 18
    bb4_index = 19

    bb1_smi = 22
    bb2_smi = 23
    bb3_smi = 24
    bb4_smi = 25

    enrichment_c1_index = 4    
    enrichment_c1_list = list(map(lambda x: math.log(x,10),df["enrichment(193_C1)"]))
    enrichment_c1_min = min(list(enrichment_c1_list))
    enrichment_c1_max = max(list(enrichment_c1_list))

    new_dict = {
    "nodes": [],
    "links": []
    }

    for row_index in range(1000):

        bb1 = df.iloc[row_index,bb1_index]
        bb1 = "bb1"+"_"+str(bb1)+"_"+df.iloc[row_index,bb1_smi]
        node = {"id": bb1, "group": 1}
        if node not in new_dict["nodes"]:
            new_dict["nodes"].append({"id": bb1, "group": 1})

        bb2 = df.iloc[row_index,bb2_index]
        bb2 = "bb2"+"_"+str(bb2)+"_"+df.iloc[row_index,bb2_smi]
        node = {"id": bb2, "group": 1}
        if node not in new_dict["nodes"]:
            new_dict["nodes"].append({"id": bb2, "group": 1})

        bb3 = df.iloc[row_index,bb3_index]
        bb3 = "bb3"+"_"+str(bb3)+"_"+df.iloc[row_index,bb3_smi]
        node = {"id": bb3, "group": 1}
        if node not in new_dict["nodes"]:
            new_dict["nodes"].append({"id": bb3, "group": 1})

        bb4 = df.iloc[row_index,bb4_index]
        bb4 = "bb4"+"_"+str(bb4)+"_"+df.iloc[row_index,bb4_smi]
        node = {"id": bb4, "group": 1}
        if node not in new_dict["nodes"]:
            new_dict["nodes"].append({"id": bb4, "group": 1})

        new_dict["links"].append({"source": bb1, "target": bb2, "value": 1})
        new_dict["links"].append({"source": bb2, "target": bb3, "value": 1})
        new_dict["links"].append({"source": bb3, "target": bb4, "value": 1})






    with open("data.json","w") as f:
        json.dump(new_dict,f)
        print("加载入文件完成...")




if __name__=="__main__":
    csv_name= "data.csv"
    csv2graph(csv_name)